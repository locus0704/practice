/*
 * 1~10까지 출력
 * 숫자를 입력 받아서 입력받은 수의 배수는 그대로 출력하고
 * 배수가 아닌 수는 2 배수를 출력한다.
 * 
 * 수를 입력: 3
 * 2
 * 4
 * 3
 * 8
 * 10
 * 6
 */
package day02_quiz;

import java.util.Scanner;

public class Quiz10 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	
	System.out.print("수를 입력: ");
	int num=sc.nextInt();
		
	for(int i=1; i<=10; i++) {
		
		if(i%num==0) {
			System.out.println(i);
		}else {
			System.out.println(i*2);
		}
	}
	
}
}
