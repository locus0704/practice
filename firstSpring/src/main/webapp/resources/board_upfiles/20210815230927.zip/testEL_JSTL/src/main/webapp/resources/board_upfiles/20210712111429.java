/*
 *  1부터 입력된 수까지 의 합을 구하는 프로그램 작성
 *  수: -8
 *  0보다 큰수를 입력하세요
 *  수: 3
 *  1부터 3까지의 합 :6
 */
package day02_quiz;

import java.util.Scanner;

public class Quiz14 {
 public static void main(String[] args) {
	 Scanner sc= new Scanner(System.in);
	
	int num=0;
	while(true) {
		System.out.println("수: ");
		num=sc.nextInt();
		if(num<=0) {
			System.out.println("0보다 큰수를 입력하세요");
			
		}else {
			break;
		}
	}
	int sum=0;
	for(int i=1; i<=num; i++) {
		sum+=i;
	}System.out.printf("1부터 %d 까지의합: %d", num,sum);
 }
}
	 

	 
	 
	 
	 
	 
	 
	 
	 




















/* System.out.print("수: ");
	 int num=sc.nextInt();
	 int sum=0;
	 int i =0;
	 while(i++<num) {
		 sum+=i;
	 }System.out.println("합 "+sum );
	System.out.println("0보다 큰수를 입력하세요");
}*/

