package notice.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import notice.model.service.NoticeService;
import notice.model.vo.Notice;

/**
 * Servlet implementation class NoticeNewTop3Servlet
 */
@WebServlet("/ntop3")
public class NoticeNewTop3Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NoticeNewTop3Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ajax 통신으로 최근 공지글 3개 조회 처리용 컨트롤러
		
		ArrayList<Notice> list = new NoticeService().selectNewTop3();
		
		//list 를 옮겨 기록할 JSON 배열 생성
		JSONArray jarr = new JSONArray();
		
		//list 애서 Notice 객체 하나씩 꺼내서 json 배열에
		//json 객체로 값 옮겨 기록하기
		for(Notice notice : list) {
			//notice 저장용 json 객체 생성
			JSONObject job = new JSONObject();
			
			job.put("no", notice.getNoticeNo());
			job.put("title", URLEncoder.encode(notice.getNoticeTitle(), "utf-8"));
			job.put("date", notice.getNoticeDate().toString());
			
			jarr.add(job);
		}
		
		//전송용 json 객체 생성
		JSONObject sendJson = new JSONObject();
		sendJson.put("list", jarr);
		
		//요청자에게 보내기
		response.setContentType("application/json; charset=utf-8");
		PrintWriter out = response.getWriter();
		out.write(sendJson.toJSONString());
		out.flush();
		out.close();
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
