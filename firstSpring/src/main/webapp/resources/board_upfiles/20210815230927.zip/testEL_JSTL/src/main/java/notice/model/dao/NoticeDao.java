package notice.model.dao;

import static common.JDBCTemp.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import notice.model.vo.Notice;

public class NoticeDao {

	//공지사항 전체조회 : 공지사항 목록보기용
	public ArrayList<Notice> selectList(Connection conn){
		ArrayList<Notice> list = new ArrayList<Notice>();
		Statement stmt = null;
		ResultSet rset = null;
		
		String query = "SELECT * FROM NOTICE "
				+ "ORDER BY NOTICENO DESC";
		
		try {
			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			
			while(rset.next()) {
				Notice notice = new Notice();
				
				notice.setNoticeNo(rset.getInt("noticeno"));
				notice.setNoticeTitle(rset.getString("noticetitle"));
				notice.setNoticeContent(rset.getString("noticecontent"));
				notice.setNoticeDate(rset.getDate("noticedate"));
				notice.setOriginalFilepath(rset.getString("original_filepath"));
				notice.setRenameFilepath(rset.getString("rename_filepath"));
				notice.setNoticeWriter(rset.getString("noticewriter"));
				
			
				list.add(notice);
			}
		} catch (Exception e) {
             e.printStackTrace();
		}finally {
			close(rset);
			close(stmt);
		}
		return list;
	}
	
	//공지글번호로 한 개 조회 : 공지사항 상세보기용
	public Notice selectOne(Connection conn, int noticeNo) {
		Notice notice = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		
		String query = "select * from notice where noticeno = ?";
		    
		
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, noticeNo);
			
			rset = pstmt.executeQuery();
			
			if(rset.next()) {
				notice = new Notice();
				
				notice.setNoticeNo(rset.getInt("noticeno"));
				notice.setNoticeTitle(rset.getString("noticetitle"));
				notice.setNoticeContent(rset.getString("noticecontent"));
				notice.setNoticeDate(rset.getDate("noticedate"));
				notice.setOriginalFilepath(rset.getString("original_filepath"));
				notice.setRenameFilepath(rset.getString("rename_filepath"));
				notice.setNoticeWriter(rset.getString("noticewriter"));
				
			}
		} catch (Exception e) {
           e.printStackTrace();
		}finally {
			close(rset);
			close(pstmt);
		}
		
		
		return notice;
	}
	
	//새 공지글 등록
	public int insertNotice(Connection conn, Notice notice) {
		int result = 0;
		PreparedStatement pstmt = null;
		
		String query = "insert into notice values ((select max(noticeno) + 1 from notice), ?, sysdate, ?, ?, ?, ?)";
		
		try {
			   pstmt = conn.prepareStatement(query);
			   pstmt.setString(1, notice.getNoticeTitle());
			   pstmt.setString(2, notice.getNoticeWriter());
			   pstmt.setString(3, notice.getNoticeContent());
			   pstmt.setString(4, notice.getOriginalFilepath());
			   pstmt.setString(5, notice.getRenameFilepath());
			
			   
			   result = pstmt.executeUpdate();
			
		} catch (Exception e) {
             e.printStackTrace();
		}finally {
			close(pstmt);
		}
		
		return result;
	}
	
	//공지글 수정
	public int updateNotice(Connection conn, Notice notice) {
		int result = 0;
		PreparedStatement pstmt = null;
		
		String query ="update notice set noticetitle = ?, noticewriter = ?, noticecontent = ?, noticedate = sysdate, original_filepath = ?, rename_filepath = ? where notcieno = ?";
		
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, notice.getNoticeTitle());
			pstmt.setString(2, notice.getNoticeWriter());
			pstmt.setString(3, notice.getNoticeContent());
			pstmt.setString(4, notice.getOriginalFilepath());
			pstmt.setString(5, notice.getRenameFilepath());
			pstmt.setInt(6, notice.getNoticeNo());
			
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		return result;
	}
	
	//공지글 삭제
	public int deleteNotice(Connection conn, int noticeNo) {
		int result = 0;
		PreparedStatement pstmt = null;
		
		String query = "delete from notice where noticeno = ?";
	
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, noticeNo);
			
			result = pstmt.executeUpdate();
	} catch (Exception e) {
		e.printStackTrace();
	}finally {
		close(pstmt);
	}
		
		
		
		return result;
	}
	
	//새 공지글 3개를 리턴 : 작성날짜로 top-3 분석 이용함
	public ArrayList<Notice> selectNewTop3(Connection conn){
		ArrayList<Notice> list = new ArrayList<Notice>();
		Statement stmt = null;
		ResultSet rset = null;
		
		String query = "SELECT * " +
				"FROM (SELECT ROWNUM RNUM, NOTICENO, NOTICETITLE, NOTICEDATE "
				+ "FROM ( SELECT * FROM NOTICE "
				+ "                ORDER BY NOTICEDATE DESC)) "
				+ "WHERE RNUM BETWEEN 1 AND 3";
		
		try {
			stmt = conn.createStatement();
			rset = stmt.executeQuery(query);
			
			while(rset.next()) {
				Notice notice = new Notice();
				
				notice.setNoticeNo(rset.getInt("noticeno"));
				notice.setNoticeTitle(rset.getString("noticetitle"));
				notice.setNoticeDate(rset.getDate("noticedate"));
				
				list.add(notice);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(stmt);
		}
		
		return list;
	}
}







